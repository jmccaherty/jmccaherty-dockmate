import streamlit as st
from utils.calendar import get_available_days

if not st.session_state.get("authenticated"):
    st.error("Please login first.")
    st.stop()

st.title(f"{st.session_state['role']} Dashboard")

if st.session_state["role"] == "Boat Owner":
    st.markdown("### Book a Service")
    services = ["Crane", "Trucking", "Launch"]
    selected = st.multiselect("Select Services", services)
    available = get_available_days(selected)
    st.write("Available Dates for All Selected Services:")
    st.json(available)

elif st.session_state["role"] == "Vendor":
    st.markdown("### Vendor Setup")
    st.write("Connect your Stripe account below:")
    st.markdown("[Connect with Stripe](https://connect.stripe.com/oauth/authorize?response_type=code&client_id=ca_xxxxxx&scope=read_write)")
    st.markdown("Update availability and capacity soon...")

elif st.session_state["role"] == "Marina Admin":
    st.markdown("### Admin Tools")
    st.write("Manage vendor approvals, fee dependencies, and availability rules.")
